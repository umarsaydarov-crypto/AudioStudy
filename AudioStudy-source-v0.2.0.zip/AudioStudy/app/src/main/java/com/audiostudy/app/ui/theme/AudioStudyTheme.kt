package com.audiostudy.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Blue = Color(0xFF4779D0)
private val LightScheme = lightColorScheme(
    primary = Blue,
    onPrimary = Color.White,
    background = Color(0xFFF8F9FC),
    surface = Color.White,
    surfaceVariant = Color(0xFFF0F2F7),
    onBackground = Color(0xFF171A21),
    onSurface = Color(0xFF171A21),
    onSurfaceVariant = Color(0xFF656B78)
)

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF9DBBFF),
    background = Color(0xFF111318),
    surface = Color(0xFF191C23),
    surfaceVariant = Color(0xFF242833),
    onBackground = Color(0xFFE9ECF3),
    onSurface = Color(0xFFE9ECF3),
    onSurfaceVariant = Color(0xFFB4BAC7)
)

@Composable
fun AudioStudyTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = if (dark) DarkScheme else LightScheme,
        content = content
    )
}
