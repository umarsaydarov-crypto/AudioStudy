package com.audiostudy.app.model

/** Domain model for a library project. Persistence will be added with Room. */
data class LibraryProject(
    val id: String,
    val title: String,
    val audioCount: Int = 0,
    val isFavorite: Boolean = false,
    val isFolder: Boolean = false
)
