package com.audiostudy.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class SavedRecording(
    val file: File,
    val durationMs: Long
) {
    val title: String get() = file.nameWithoutExtension
}

@Composable
fun RecorderScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val recordingsDirectory = remember { File(context.filesDir, "recordings").apply { mkdirs() } }

    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var activeFile by remember { mutableStateOf<File?>(null) }
    var isRecording by remember { mutableStateOf(false) }
    var isPaused by remember { mutableStateOf(false) }
    var startedAt by remember { mutableStateOf(0L) }
    var elapsedMs by remember { mutableStateOf(0L) }
    var records by remember { mutableStateOf(emptyList<SavedRecording>()) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var playingPath by remember { mutableStateOf<String?>(null) }
    var renameTarget by remember { mutableStateOf<File?>(null) }
    var renameText by remember { mutableStateOf("") }
    var deleteTarget by remember { mutableStateOf<File?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    fun refreshRecords() {
        records = recordingsDirectory.listFiles()
            ?.filter { it.isFile && it.extension.equals("m4a", ignoreCase = true) }
            ?.map { file -> SavedRecording(file, readDuration(file)) }
            ?.sortedByDescending { it.file.lastModified() }
            ?: emptyList()
    }

    fun finishRecording() {
        val currentRecorder = recorder
        val currentFile = activeFile
        try {
            currentRecorder?.stop()
        } catch (_: RuntimeException) {
            currentFile?.delete()
        } finally {
            currentRecorder?.release()
            recorder = null
            activeFile = null
            isRecording = false
            isPaused = false
            elapsedMs = 0L
            refreshRecords()
        }
    }

    fun beginRecording() {
        try {
            val file = File(recordingsDirectory, "Запись_${timestampForFile()}.m4a")
            val newRecorder = MediaRecorder()
            newRecorder.setAudioSource(MediaRecorder.AudioSource.MIC)
            newRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            newRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            newRecorder.setAudioSamplingRate(44100)
            newRecorder.setAudioEncodingBitRate(128000)
            newRecorder.setOutputFile(file.absolutePath)
            newRecorder.prepare()
            newRecorder.start()
            recorder = newRecorder
            activeFile = file
            startedAt = SystemClock.elapsedRealtime()
            elapsedMs = 0L
            isRecording = true
            isPaused = false
            message = null
        } catch (error: Exception) {
            recorder?.release()
            recorder = null
            activeFile?.delete()
            activeFile = null
            message = "Не удалось начать запись: ${error.localizedMessage ?: "проверьте микрофон"}"
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) beginRecording() else message = "Для записи нужно разрешить доступ к микрофону."
    }

    val latestRecorder by rememberUpdatedState(recorder)
    val latestActiveFile by rememberUpdatedState(activeFile)
    val latestPlayer by rememberUpdatedState(player)

    LaunchedEffect(Unit) { refreshRecords() }
    LaunchedEffect(isRecording, isPaused) {
        while (isRecording) {
            if (!isPaused) elapsedMs = SystemClock.elapsedRealtime() - startedAt
            delay(250)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            try {
                latestRecorder?.let {
                    try { it.stop() } catch (_: RuntimeException) { latestActiveFile?.delete() }
                    it.release()
                }
            } catch (_: Exception) { }
            latestPlayer?.release()
        }
    }

    Column(
        modifier = modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Диктофон", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Surface(
                    modifier = Modifier.size(76.dp),
                    shape = CircleShape,
                    color = if (isRecording && !isPaused) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surface
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            if (isRecording) Icons.Default.GraphicEq else Icons.Default.Mic,
                            contentDescription = null,
                            modifier = Modifier.size(36.dp),
                            tint = if (isRecording && !isPaused) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                        )
                    }
                }
                Text(
                    when { isPaused -> "Запись на паузе"; isRecording -> "Идёт запись"; else -> "Готово к записи" },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Text(formatDuration(elapsedMs), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Medium)
                if (!isRecording) {
                    Button(
                        onClick = {
                            val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                            if (granted) beginRecording() else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = null)
                        Text("  Начать запись")
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = {
                            try {
                                if (isPaused) {
                                    recorder?.resume()
                                    startedAt = SystemClock.elapsedRealtime() - elapsedMs
                                    isPaused = false
                                } else {
                                    recorder?.pause()
                                    isPaused = true
                                }
                            } catch (error: Exception) {
                                message = "Не удалось изменить состояние записи: ${error.localizedMessage}"
                            }
                        }) {
                            Icon(if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause, contentDescription = null)
                            Text(if (isPaused) "  Продолжить" else "  Пауза")
                        }
                        Button(onClick = { finishRecording() }) {
                            Icon(Icons.Default.Stop, contentDescription = null)
                            Text("  Сохранить")
                        }
                    }
                }
                Text(
                    "Записи сохраняются на устройстве и доступны без интернета.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Мои записи", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            Text("${records.size}", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        if (records.isEmpty()) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Mic, contentDescription = null, modifier = Modifier.size(42.dp), tint = MaterialTheme.colorScheme.primary)
                    Text("Пока нет записей", fontWeight = FontWeight.SemiBold)
                    Text("Создайте первую запись лекции или заметки.", color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                }
            }
        } else {
            LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(records, key = { it.file.absolutePath }) { item ->
                    RecordingRow(
                        item = item,
                        isPlaying = playingPath == item.file.absolutePath,
                        onPlay = {
                            try {
                                player?.release()
                                if (playingPath == item.file.absolutePath) {
                                    player = null
                                    playingPath = null
                                } else {
                                    val newPlayer = MediaPlayer()
                                    newPlayer.setDataSource(item.file.absolutePath)
                                    newPlayer.setOnCompletionListener {
                                        it.release()
                                        player = null
                                        playingPath = null
                                    }
                                    newPlayer.prepare()
                                    newPlayer.start()
                                    player = newPlayer
                                    playingPath = item.file.absolutePath
                                }
                            } catch (error: Exception) {
                                message = "Не удалось воспроизвести запись: ${error.localizedMessage}"
                            }
                        },
                        onRename = { renameTarget = item.file; renameText = item.title },
                        onDelete = { deleteTarget = item.file }
                    )
                }
            }
        }
    }

    if (renameTarget != null) {
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Переименовать запись") },
            text = {
                OutlinedTextField(value = renameText, onValueChange = { renameText = it }, singleLine = true, label = { Text("Название") })
            },
            confirmButton = {
                TextButton(onClick = {
                    val target = renameTarget
                    val safeName = renameText.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
                    if (target != null && safeName.isNotBlank()) {
                        target.renameTo(File(recordingsDirectory, "$safeName.m4a"))
                        refreshRecords()
                    }
                    renameTarget = null
                }) { Text("Сохранить") }
            },
            dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("Отмена") } }
        )
    }

    if (deleteTarget != null) {
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Удалить запись?") },
            text = { Text("Файл будет удалён с устройства.") },
            confirmButton = {
                TextButton(onClick = {
                    deleteTarget?.delete()
                    if (playingPath == deleteTarget?.absolutePath) {
                        player?.release(); player = null; playingPath = null
                    }
                    deleteTarget = null
                    refreshRecords()
                }) { Text("Удалить") }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Отмена") } }
        )
    }

    if (message != null) {
        AlertDialog(
            onDismissRequest = { message = null },
            title = { Text("AudioStudy") },
            text = { Text(message.orEmpty()) },
            confirmButton = { TextButton(onClick = { message = null }) { Text("Понятно") } }
        )
    }
}

@Composable
private fun RecordingRow(
    item: SavedRecording,
    isPlaying: Boolean,
    onPlay: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 10.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.size(42.dp).clickable(onClick = onPlay)) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = "Прослушать", tint = MaterialTheme.colorScheme.primary)
                }
            }
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(item.title, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(
                    "${formatDuration(item.durationMs)} • ${SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(item.file.lastModified()))}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onRename) { Icon(Icons.Default.Edit, contentDescription = "Переименовать") }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "Удалить") }
        }
    }
}

private fun readDuration(file: File): Long {
    val retriever = MediaMetadataRetriever()
    return try {
        retriever.setDataSource(file.absolutePath)
        retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
    } catch (_: Exception) {
        0L
    } finally {
        retriever.release()
    }
}

private fun timestampForFile(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

private fun formatDuration(milliseconds: Long): String {
    val totalSeconds = (milliseconds / 1000).coerceAtLeast(0)
    return "%02d:%02d:%02d".format(totalSeconds / 3600, (totalSeconds % 3600) / 60, totalSeconds % 60)
}
