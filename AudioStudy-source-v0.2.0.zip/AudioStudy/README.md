# AudioStudy — Android project scaffold

Первая исходная сборка проекта: минималистичный интерфейс главного экрана, нижняя навигация, пустые состояния библиотеки/избранного/плейлистов, список категорий настроек и системный выбор документов.

## Техническая основа

- Kotlin
- Jetpack Compose + Material 3
- Android Gradle Plugin 8.9.2
- Kotlin 2.1.20
- `minSdk = 29` (Android 10)
- `compileSdk = 35`
- Package: `com.audiostudy.app`

## Открытие

1. Установить Android Studio с Android SDK Platform 35.
2. Открыть папку `AudioStudy` в Android Studio.
3. Дождаться синхронизации Gradle и установки зависимостей.
4. Запустить конфигурацию `app` на эмуляторе или Android-телефоне.

В этой рабочей среде нет Android SDK, Gradle и доступа к сети, поэтому APK здесь не собран и компиляция Android-кода не подтверждена. Проект содержит Gradle Kotlin DSL, но wrapper JAR не включён; Android Studio сможет открыть проект с локальной установкой Gradle либо wrapper можно сгенерировать командой `gradle wrapper` после установки Gradle 8.11.1.

## Текущее состояние

Реализовано в этом каркасе:
- главный экран AudioStudy;
- минималистичная светлая/тёмная палитра по системной теме;
- нижняя навигация: Библиотека, Избранное, Плейлисты, Настройки;
- поиск по проектам (пока по локальному списку в памяти);
- переключение компактного списка и сетки карточек;
- кнопка импорта и системный выбор нескольких документов;
- экран категорий настроек.

Пока не реализованы: постоянное хранение в Room, фактический импорт/парсинг/OCR, создание проектов, TTS, синхронизация слов, полноценный плеер, облако и резервное копирование. Они остаются в согласованном плане разработки; интерфейсные заглушки не выдают их за готовые функции.


## Version 0.2.0

Added a local voice recorder: microphone permission, AAC/M4A recording, pause/resume, save, playback, rename, and delete. Recordings are stored in the app's private files directory (`files/recordings`) and work offline. Recording currently runs while the recorder screen is open; background recording service and database-backed metadata are planned for a later stage.
